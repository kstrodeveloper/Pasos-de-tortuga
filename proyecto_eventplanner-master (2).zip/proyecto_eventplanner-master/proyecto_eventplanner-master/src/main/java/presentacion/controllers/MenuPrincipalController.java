package presentacion.controllers;
import java.util.function.Consumer;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

/**
 * Controlador del Menú Principal
 */
public class MenuPrincipalController {
    
    @FXML
    private void abrirGestionEventos() {
        mostrarMensaje("Gestión de Eventos", "Esta funcionalidad se implementará próximamente");
    }
    
    @FXML
    private void abrirGestionParticipantes() {
        mostrarMensaje("Gestión de Participantes", "Esta funcionalidad se implementará próximamente");
    }
    
    @FXML
    private void abrirSistemaPagos() {
        mostrarMensaje("Sistema de Pagos", "Esta funcionalidad se implementará próximamente");
    }
    
    @FXML
    private void abrirReportes() {
        mostrarMensaje("Reportes", "Esta funcionalidad se implementará próximamente");
    }
    
    @FXML
    private void salir() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Salir");
        alert.setHeaderText("¿Está seguro que desea salir?");
        alert.setContentText("Se cerrará la aplicación");
        
        alert.showAndWait().ifPresent((var response) -> {
            if (response.getText().equals("OK")) {
                System.exit(0);
            }
        });
    }
    
    private void mostrarMensaje(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}