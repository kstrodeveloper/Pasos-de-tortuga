/**
 * Clase principal de la interfaz gráfica JavaFX
 * 
 * @author Ayner Jose Castro Benavides
 * @version 1.0
 */
package presentacion;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.net.URL;

public class Main extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        try {
            // Buscar el FXML
            URL fxmlLocation = getClass().getResource("/fxml/MenuPrincipal.fxml");
            
            // Verificar que existe
            if (fxmlLocation == null) {
                System.err.println(" ERROR: No se encuentra MenuPrincipal.fxml");
                System.err.println("Verifica que el archivo esté en: src/main/resources/fxml/");
                return;
            }
            
            System.out.println(" FXML encontrado en: " + fxmlLocation);
            
            // Cargar el FXML
            FXMLLoader loader = new FXMLLoader(fxmlLocation);
            Parent root = loader.load();
            
            // Crear la escena
            Scene scene = new Scene(root, 800, 600);
            
            // Buscar CSS
            URL cssLocation = getClass().getResource("/fxml/styles.css");
            if (cssLocation != null) {
                scene.getStylesheets().add(cssLocation.toExternalForm());
                System.out.println(" CSS encontrado en: " + cssLocation);
            } else {
                System.out.println("  CSS no encontrado, continuando sin estilos");
            }
            
            // Configurar ventana
            primaryStage.setTitle("Event Planner - Sistema de Gestión");
            primaryStage.setScene(scene);
            primaryStage.setResizable(true);
            primaryStage.setMinWidth(700);
            primaryStage.setMinHeight(500);
            primaryStage.show();
            
            System.out.println(" Aplicación iniciada correctamente");
            
        } catch (Exception e) {
            System.err.println(" ERROR al cargar la interfaz:");
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}